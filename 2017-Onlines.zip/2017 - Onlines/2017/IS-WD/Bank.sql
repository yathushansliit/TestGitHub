CREATE TYPE Account_t AS OBJECT (
accNo INTEGER,
accName VARCHAR2(50),
balance FLOAT
) NOT FINAL NOT INSTANTIABLE;
/


CREATE TYPE Savings_t UNDER Account_t (
interest_rate FLOAT
);
/

CREATE TYPE Current_t UNDER Account_t (
No_cheques_issued INTEGER
);
/

CREATE TYPE Account_Ref_t AS OBJECT (
account REF Account_t
);
/

CREATE TYPE Account_Ref_tbl AS TABLE OF Account_Ref_t;
/


CREATE TYPE Customer_t AS OBJECT (
nic CHAR(10),
name VARCHAR2(50),
accounts Account_Ref_tbl 
); 
/

CREATE TABLE Accounts OF Account_t (PRIMARY KEY(accNo));
CREATE TABLE Customers OF Customer_t (PRIMARY KEY (nic)) NESTED TABLE accounts STORE AS st_acc_tbl;


INSERT INTO Accounts VALUES (Savings_t(10, 'Ran Surakum', 1000000, 4.5));
INSERT INTO Accounts VALUES (Current_t(4, 'Normal Checking', 23490.0, 156));
INSERT INTO Accounts VALUES (Savings_t(2, 'Ran Surakum', 12000, 4.5));
INSERT INTO Accounts VALUES (Current_t(12, 'Business Account', 234521.33, 1347));

INSERT INTO Customers VALUES ('1234567890', 'Mr. Suraweeraratne', 
Account_Ref_tbl (
Account_Ref_t((select REF(a1) from Accounts a1 where a1.accNo = 10)),
Account_Ref_t((select REF(a2) from Accounts a2 where a2.accNo = 4))
)
);

INSERT INTO Customers VALUES ('1232267890', 'Mr. Peiris',
Account_Ref_tbl(
Account_Ref_t((select REF(a) from Accounts a where a.accNo = 2))
)
);

INSERT INTO Customers VALUES ('1232288890', 'Mr. Wijetunga',
Account_Ref_tbl(
Account_Ref_t((select REF(a) from Accounts a where a.accNo = 12))
)
);
