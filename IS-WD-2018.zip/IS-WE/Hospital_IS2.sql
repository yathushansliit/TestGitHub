
CREATE TYPE Person_ty_IS2 AS OBJECT (
  nic CHAR(10),
  firstname varchar2(50),
  surname varchar2(50),
  member function getID return char
) not final not instantiable;
/

CREATE OR REPLACE TYPE BODY Person_ty_IS2 AS
 MEMBER FUNCTION getID RETURN CHAR IS
 BEGIN
   RETURN nic;
 END;
END;
/

CREATE TYPE Doctor_ty_IS2 UNDER Person_ty_IS2(
 regNo CHAR(10),
 specialty VARCHAR2(25)
);
/

CREATE TYPE Admission_ty_IS2 AS OBJECT (
  adDate DATE,
  dischDate DATE,
  illness VARCHAR2(25),
  assgnDoctor REF Doctor_ty_IS2 
);
/

CREATE TYPE Admission_ty_tlb AS TABLE OF Admission_ty_IS2;
/

CREATE TYPE Patient_ty_IS2 UNDER Person_ty_IS2(
  pid CHAR(10),
  admissions Admission_ty_tlb
);
/

CREATE TABLE People_IS2 OF Person_ty_IS2;