
CREATE TYPE Person_ty AS OBJECT (
  nic CHAR(10),
  firstname varchar2(50),
  surname varchar2(50),
  member function getID return char
) not final not instantiable;
/

CREATE OR REPLACE TYPE BODY Person_ty AS
 MEMBER FUNCTION getID RETURN CHAR IS
 BEGIN
   RETURN nic;
 END;
END;
/

CREATE TYPE Doctor_ty UNDER Person_ty (
 regNo CHAR(10),
 specialty VARCHAR2(25)
);
/

CREATE TYPE Admission_ty AS OBJECT (
  adDate DATE,
  dischDate DATE,
  illness VARCHAR2(25),
  assgnDoctor REF Doctor_ty
);
/

CREATE TYPE Admission_ty_tlb AS TABLE OF Admission_ty;
/

CREATE TYPE Patient_ty UNDER Person_ty (
  pid CHAR(10),
  admissions Admission_ty_tlb
);
/

CREATE TABLE People OF Person_ty;